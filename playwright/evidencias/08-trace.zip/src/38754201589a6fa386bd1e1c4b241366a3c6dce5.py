from playwright.sync_api import Page, expect


def test_fallo_controlado(page: Page):
    page.goto("/auth/login")
    expect(page.locator("#email")).to_be_visible()
    expect(page.locator("#btnLogin")).to_have_text("Entrar")
